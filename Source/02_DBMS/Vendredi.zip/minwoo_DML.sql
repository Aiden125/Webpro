-- MAPPERS
----------------------------------------------------------------------
--                          MEMBER.Xml                              --
----------------------------------------------------------------------
-- (1)  id = memberLogin (로그인)
SELECT * FROM MEMBER WHERE MID ='aaa' and mpw='1';
-- (2)  id = memberJoin (회원가입) 
INSERT INTO MEMBER VALUES('son', '손흥민','1', '010-6789-6789','son@naver.com','서울시 강남구 청담동','남자','1992/07/08','1.jpg');
-- (3)  id = memberSearchId(아이디 찾기)
SELECT MID FROM MEMBER WHERE MNAME = '손흥민' AND MEMAIL ='son@naver.com' ;
-- (4)  id = memberSearchPw(비밀번호 찾기)
SELECT Mpw FROM MEMBER WHERE MID = 'son' AND Mname ='손흥민' ;
-- (5)  id = memberGetDetail (mid로 dto가져오기)
SELECT * FROM MEMBER WHERE MID='son';
-- (6)  id = memberModify(회원정보 수정)
UPDATE MEMBER SET MPW = '111',
                  MNAME = '손흥민',
                  mtel = '010-0000-1111',
                  memail = 'sony@naver.com',
                  maddress = '서울시 강남구 대치동',   
                  mprofile = 'son.jpg'
                 where mid = 'son';
-- (7) id= memberTotCnt( 회원수)                 
select count(*)cnt from MEMBER;
commit;
-- (8) id=memberWithdrawal (회원탈퇴)
delete from MEMBER where mid = 'carlos';


----------------------------------------------------------------------
--                           QnA.xml                              --
----------------------------------------------------------------------
-- id = qnaTotCnt (글 갯수)   
SELECT COUNT(*)CNT FROM QNA;

-- (1) id= qnaList (문의글 목록 paiging처리, 최신글 순  )                   
SELECT * FROM (SELECT ROWNUM RN, A.* FROM 
    (select qno, qid, qsubject, qcontent, qhit, qgroup, qstep, qrdate, qsecret,
    (select count(*) from qna where qno=q.qno and qstep>0 ) replyok
    from qna Q order by qgroup) A)
    WHERE RN BETWEEN 1 AND 3;

-- 변경1
select qno, qid, qsubject, qcontent, qhit, qgroup, qstep, qrdate, qsecret,
    (select count(*) from QNA where qno=Q.qno and qstep>0 ) replyok
    from QNA Q order by qgroup limit 0, 2;


-- 답변완료 여부 나타내는 페이징 리스트(질문글만 보이게) - 희석 추가
SELECT * FROM
    (SELECT ROWNUM RN, A.* FROM (SELECT * FROM QNA WHERE QSTEP=0 ORDER BY QRDATE DESC) A)
    WHERE RN BETWEEN 1 AND 10;

-- 변경2
SELECT * FROM QNA WHERE QSTEP=0 ORDER BY QRDATE DESC limit 0,9;


-- 질문글 총 갯수 for paging - 희석 추가
SELECT COUNT(*) FROM QNA WHERE QSTEP=0;

-- 답변안된 질문만 보기 - 희석 추가
SELECT * FROM
    (SELECT ROWNUM RN, A.* FROM (SELECT * FROM QNA WHERE QSTEP=0 AND QREPLYCHECK=0 ORDER BY QRDATE DESC) A)
    WHERE RN BETWEEN 2 AND 3;

-- 변경3
SELECT * FROM QNA WHERE QSTEP=0 AND QREPLYCHECK=0 ORDER BY QRDATE DESC limit 1,2;

-- 답변안된 질문글 총 갯수 for paging - 희석 추가
SELECT COUNT(*) FROM QNA WHERE QSTEP=0 AND QREPLYCHECK=0;

-- 답변만 보기 - 희석 추가
SELECT * FROM
    (SELECT ROWNUM RN, A.* FROM (SELECT * FROM QNA WHERE QSTEP!=0 ORDER BY QRDATE DESC) A)
    WHERE RN BETWEEN 2 AND 3;

-- 변경4
SELECT * FROM QNA WHERE QSTEP!=0 ORDER BY QRDATE DESC limit 1,2;

-- 답변들 총 갯수 - 희석 추가
SELECT COUNT(*) FROM QNA WHERE QSTEP!=0;

-- 원글 상세보기
SELECT * FROM QNA WHERE QGROUP=7 AND QSTEP=0;
-- 답글 상세보기
SELECT * FROM QNA WHERE QGROUP=1 AND QSTEP!=0;
-- 질문 답변 같이보기
SELECT * FROM QNA WHERE QGROUP=250 ORDER BY QSTEP;

    
-- (2) id = qnaWrite (문의글 작성)
INSERT INTO QNA (qno,qid,qsubject,qcontent,qgroup,qstep,qreplycheck)
	VALUES
    ((SELECT get_qna_seq('qno')) , 'son','가게 사장님과 컨택질문','광고 가능한가요3?',(SELECT qno FROM (SELECT MAX(qno)+1 AS qno FROM QNA) qna) ,0,0);


-- 비밀글인 문의글 작성하기
INSERT INTO QNA (qno,qid,qsubject,qcontent,qgroup,qstep,qreplycheck, qsecret)
	VALUES
    ((SELECT get_qna_seq('qno')) , 'son','가게 사장님과 컨택질문','광고 가능한가요3?',(SELECT qno FROM (SELECT MAX(qno)+1 AS qno FROM QNA) qna) ,0,0, 'Y');
    
SELECT * FROM QNA;

-- (3) id = qnaModify (문의글 수정) 제목, 내용 
update QNA set 
    qsubject = '질문',
    qcontent = '업체문의는 어디서 해야하나요'   
    where qno = 1;
    
-- (4) id = qnaDetail (문의글 상세보기) 
select * from QNA where qno=1;

-- () id = qnaHitup(조회수 증가)
update QNA set qhit = qhit +1 where qno=2;

-- (4) id = qnaReplyPre (답변글 쓰기 전 step A)
UPDATE  QNA SET QSTEP=QSTEP +1 WHERE QGROUP = 1 ;

SELECT * FROM QNA  ORDER BY QGROUP ;

-- (4) id = qnaReplyWrite (문의글 답변)
INSERT INTO QNA (QNO, QID, QSUBJECT, QCONTENT,QGROUP,QSTEP, QREPLYCHECK)
    VALUES ((SELECT get_qna_seq('qno')), '관리자','1번글 답변','연락 드리겠습니다',1,1, 1);
    
-- (4) id = qnaReplyAfter (답변이 완료되면 제목에 답변완료 추가)
select qno, qid, qsubject, qcontent,qhit, qgroup, qstep, qrdate, qsecret,
    (select count(*) from qna where qno=q.qno and qstep>0 ) replyok
  from qna Q order by qgroup; -- <c:if test="${replyok eq 1 and qstep eq 0 }"> 답변완료</c:if>
  
  
-- id= qnaList (문의글 목록 paiging처리, 최신글 순, 답변완료 여부  )
SELECT * FROM (SELECT ROWNUM RN, A.* FROM (SELECT * FROM QNA ORDER BY QRDATE DESC)A)
    WHERE RN BETWEEN 1 AND 3;
 
 -- 변경
 SELECT * FROM QNA ORDER BY QRDATE DESC LIMIT 0,2;
 
-- (5) id = qnaReplyDelete (문의글 삭제)
DELETE FROM QNA WHERE QNO= 11;
COMMIT;

package strategy3;

public class JobLec implements IJob {

	@Override
	public void job() {
		System.out.println("���Ǹ� �մϴ�.");

	}

}

package strategy3;

public interface IGet {
	public void get();
}

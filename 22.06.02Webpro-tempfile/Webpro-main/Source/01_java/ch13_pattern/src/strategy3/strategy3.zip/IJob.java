package strategy3;

public interface IJob {
	public void job();
}

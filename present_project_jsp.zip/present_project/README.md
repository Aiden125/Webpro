<h2>Personal Project</h2>
MBTI별 선물 추천 게시판 프로젝트입니다.